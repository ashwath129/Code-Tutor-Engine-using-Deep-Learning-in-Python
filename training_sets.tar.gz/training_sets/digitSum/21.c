//#include <stdio.h>
int main()
{
	int sum = 0, n;
	scanf("%d", &n);
    while(n > 0 || sum > 9)
   	{
      	if(n == 0)
       	{
       		n = sum;
       		sum = 0;
       	}
       	sum += n % 10;
       	n /= 10;
    }
	printf("%d", sum);
	return 0;
}
