//#include <stdio.h>  
//#include <string.h>  

int main()  
{  
    long decimal, tempDecimal;  
    char binary[65], temp;  
    int index = 0, length,i;  

    /* 
     * Reads decimal number from user 
     */  
    printf("Enter any decimal value : ");  
    scanf("%ld", &decimal);  

    /* Copies decimal value to temp variable */  
    tempDecimal = decimal;  

    while(tempDecimal!=0)  
    {  
        /* Finds decimal%2 and adds to the binary value */  
        binary[index] = (tempDecimal % 2) + '0';  

        tempDecimal /= 2;  
        index++;  
    }  
    binary[index] = '\0';  

    /* Reverse the binary value found */  
      
	length = strlen(binary);
	for(i=0; i<length/2; i++)
	{
		temp = binary[i];
		binary[i] = binary[length-i-1];
		binary[length-i-1] = temp;
	}
	
    printf("\nDecimal value = %ld\n", decimal);  
    printf("Binary value of decimal = %s", binary);  

    return 0;  
} 

