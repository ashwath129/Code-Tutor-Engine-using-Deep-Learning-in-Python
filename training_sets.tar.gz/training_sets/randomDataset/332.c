//#include<stdio.h>
 
int main() {
 int num = 1342;
 printf("%d", printf("%d", printf("%d", num)));
 return(0);
}
