//#include<stdio.h>
 
int main() {
   int num1 = 10, num2 = 5, i;
 
   while (num2 > 0) {
      num1++;
      num2--;
   }
 
   printf("%d", num1);
   return (0);
}
