//#include<stdio.h>
//#include<string.h>
 
int main() {
   char *string = "Pritesh Taral";
 
   printf("String before to strupr : %sn", string);
   strupr(string);
   printf("String after strupr : %sn", string);
 
   return (0);
}
