
//#include <stdio.h>

//#include <string.h>

 

void main()

{

    char string[100], str[10], c[10];

    int z, occ = 0, i = 0, j = 0, count = 0, len = 0;

 

    printf("Enter a string:");

    scanf("%[^\n]s", string);

    printf("Enter the word to check its occurence:");

    scanf("%s", str);

    len = strlen(str);

    for (i = 0;string[i] != '\0';i++)

    {

        count = 0;

        for (j = 0, z = i;j < len; j++, z++)

        {

            c[j] = string[z];

            if (c[j] == str[j])

            {

                count++; /* Incrementing the count if the characters of the main string match with the characters of the given word */

            }

        }

        if (count == len && string[z] == ' ')

        {

            occ++;        /* Incrementing the occ if word matches completely and next character in string is space */

        }

    }

    printf("The number of occ is %d\n", occ);

}
