//#include<stdio.h>
 
int main() {
   int a, b, c;
 
   printf("\nEnter value of a, b & c : ");
   scanf("%d %d %d", &a, &b, &c);
 
   if ((a > b) && (a > c))
      printf("\na is greatest");
 
   if ((b > c) && (b > a))
      printf("\nb is greatest");
 
   if ((c > a) && (c > b))
      printf("\nc is greatest");
 
   return(0);
}
