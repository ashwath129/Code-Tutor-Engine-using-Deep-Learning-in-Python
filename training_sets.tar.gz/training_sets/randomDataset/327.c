//#include<stdio.h>
 
int main() {
   int num1 = 10, num2 = 5;
   
   num1 = num1 - (-num2);
   printf("Sum is : %d",num1);
   
   return (0);
}
