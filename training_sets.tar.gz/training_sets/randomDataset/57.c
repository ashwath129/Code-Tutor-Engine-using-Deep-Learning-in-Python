
//#include <stdio.h>

 

int main(void)

{

    //59 is the ascii value of semicolumn

    if (printf("%c ", 59))

    {

    }

    return 0;

}
