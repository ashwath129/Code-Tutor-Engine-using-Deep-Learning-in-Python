//#include <stdio.h>

int main() {
   int i, start, end;

   start = 1;
   end = 10;

   for(i = start; i <= end; i++) 
      printf("%2d\n", i);

   return 0;
}
