
//#include <stdio.h>

 

void main()

{

    if(printf("Hi.. Welcome to sanfoundry"))

    {

    }

}
