//#include<stdio.h>
 
int main() {
   int side, area;
 
   printf("\nEnter the Length of Side : ");
   scanf("%d", &side);
 
   area = side * side;
   printf("\nArea of Square : %d", area);
 
   return (0);
}
