//#include <stdio.h>

int main() {
   int n = 5;

   printf("Cube of %d = %d", n, (n*n*n));

   return 0;
}
