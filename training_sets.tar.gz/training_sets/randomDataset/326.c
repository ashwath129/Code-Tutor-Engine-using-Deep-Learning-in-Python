//#include<stdio.h>
 
int main() {
 int num1 = 10, num2 = 5, i;
 
 while (num2--) {
 num1++;
 }
 
 printf("Sum is : %d", num1);
 return (0);
}
