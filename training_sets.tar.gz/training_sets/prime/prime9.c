//#include<stdio.h>
int main()
{
    char ch;
    int a,b,flag=0;
	printf("\tEnter a no (1-2000):");
    scanf("%d",&a);
    for(b=2;b<a;b++)
    {
	    if(a%b==0 )
        {
        	flag=1;
            break;
        }
    }
    if(flag==0)
      printf("\n\t<%d> is a prime no\n",a);
    else
    	printf("\n\t<%d>  is not a prime no\n",a);
	return 0;
}

