int main()
{
	int sum;
	int fun1;
	int fun2;
	sum = fun1+fun2;
}
